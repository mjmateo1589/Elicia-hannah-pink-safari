PINK SAFARI WEBSITE INVITATION

Files:
- index.html: responsive invitation website
- photos/elicia.jpeg and photos/hannah.jpeg: the photos supplied for the invitation

Preview:
Open index.html in a web browser. Keep the photos folder beside index.html.

Before publishing:
1. Confirm the exact map pin/address for Ma’am Olives Event Center.
2. Publish the full folder (index.html and photos folder) using a static website host.
3. Test both RSVP buttons on your phone.

The RSVP buttons are connected to the Google Forms link provided.
This bundle is website content, not a publicly hosted URL yet.
